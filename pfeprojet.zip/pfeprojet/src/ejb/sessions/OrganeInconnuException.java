package ejb.sessions;

public class OrganeInconnuException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
