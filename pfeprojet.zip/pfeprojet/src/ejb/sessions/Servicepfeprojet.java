package ejb.sessions;

import java.util.List;

import ejb.entites.Batiment;
import ejb.entites.Compte;
import ejb.entites.Corrective;
import ejb.entites.DesenfumageNaturel;
import ejb.entites.Eclairage;
import ejb.entites.Entreprise;
import ejb.entites.Extincteur;
import ejb.entites.Installation;
import ejb.entites.Intervention;
import ejb.entites.MarqueEclairage;
import ejb.entites.MarqueExtincteur;
import ejb.entites.Organe;
import ejb.entites.Pdfgenere;
import ejb.entites.Pharmacie;
import ejb.entites.Piece;
import ejb.entites.Preventive;
import ejb.entites.RIA;
import ejb.entites.Signaletique;
import ejb.entites.Technicien;
import ejb.entites.TypeEclairage;
import ejb.entites.TypeExtincteur;
import ejb.entites.TypeRia;
import ejb.entites.Typetelecommande;
import ejb.entites.Verification;

public interface Servicepfeprojet {
	public List<Intervention> rechercheInterventionPdf(int numeroPdf);
	public void checkbatiment(int numerobatiment) throws BatimentInconnuException;
	public List<Organe> rechercheOrganeDefectBatiment(int numerobatiment);
	public List<Pharmacie> recherchePharmacieBatiment(int numeroBatiment);
	public Pharmacie recherchePharmacie(int numeroPharmacie);
	public List<Pharmacie> recherchePharmacieNum(int num);
	public List<Piece> recherchePieceIntervention(int numeroIntervention);
	public List<Intervention> rechercheInterventionOrgane(int numeroOrgane);
	public List<Pdfgenere> recherchePdfgenereBatiment(int numeroBatiment);
	public List<Pdfgenere> getlistePdfgenere();
	public Pharmacie ajoutPharmacie(int numbatiment, int Annee, String Emp,String Obs, int capacite)throws BatimentInconnuException;
	public Pdfgenere ajoutpdf(List<Intervention> interventions);
	public void ajoutOrgane(List<Organe> organes);
	public Compte ajouterEntreprise(String nom, String adresse,String email, String tel, String interlocuteur);
	public Compte ajouterTechnicien(String nom, String prenom, String adresse, String tel, String email);
	public void ajouterBatiment(String nomentreprise, String nom, String adresse, String nomResp, String prenomResp) throws EntrepriseInconnueException;


	public Installation InstallationOrgane(String Obs, java.sql.Date date, int numtechnicien,int numbatiment,Organe O) throws TechnicienInconnuException, BatimentInconnuException, EntrepriseInconnueException;	
	public Extincteur ajoutExtincteur(int numbatiment, int Annee, String Emp, String Obs, String nommarque, String nomtype) throws BatimentInconnuException;
	public Intervention ajoutIntervention(int numbatiment, Intervention Interv, Organe O, String conclusion) throws BatimentInconnuException;
	public Preventive MaintenancePreventiveOrgane(Organe O, String Obs, String Obsraj, int numerotechnicien, 
			java.sql.Date date, boolean marche) throws OrganeInconnuException, TechnicienInconnuException;
	public Preventive rechercheMaintenancePreventive(int numeroMaintenance);
	
	public List<Intervention> getlisteIntervention();
	public Verification Verification(int numero, String Obs, String conclusion, int numerotechnicien, java.sql.Date date, boolean marche)
			throws OrganeInconnuException, TechnicienInconnuException, BatimentInconnuException;
	
	public Extincteur remplacementextincteur(Extincteur E, int Annee, String Emp, String Obs, String nommarque, String nomtype,boolean marche);
	public Corrective MaintenanceCorrectiveOrgane(String Obs,java.sql.Date date,  int numerotechnicien, Organe O) throws TechnicienInconnuException;	
	public String rechercheObservationMaintenancecorr(int numeroOrgane);
	public String rechercheConclusionMaintenancecorrExtincteur(int numeroBatiment);
	public String rechercheConclusionMaintenancecorrPharmacie(int numeroBatiment);
	
	public List<Installation> getlisteInstallation();
	public List<Verification> getVerificationOrgane(Organe o);
	public List<Verification> getVerificationBatiment(int numeroBatiment);
	public List<Entreprise> getlisteEntreprises();
	public List<Technicien> getlisteTechniciens();

	public List<Entreprise> rechercheEntreprise(String Nom) throws EntrepriseInconnueException;
	public Entreprise rechercheEntreprisenum(int Num) throws EntrepriseInconnueException;
	public Entreprise rechercheEntrepriseemail(String email) throws EntrepriseInconnueException;
	
	public List<Technicien> rechercheTechnicien(String Nom) throws TechnicienInconnuException;
	public Technicien rechercheTechniciennum(int Num) throws TechnicienInconnuException;
	public Technicien rechercheTechnicienemail(String email) throws TechnicienInconnuException;
	
	public Batiment recherchebatiment(String nomentreprise, String Nom) throws BatimentInconnuException, EntrepriseInconnueException;
	public List<Batiment> rechercheBatimentEntreprise(int numE);
	public Batiment rechercheBatimentnum(int Num) throws BatimentInconnuException;

	public Organe rechercheOrgane(int numero) throws OrganeInconnuException;
	public Extincteur rechercheExtincteur(int numeroExtincteur);
	public List<Extincteur> rechercheExtincteurBatiment(int numeroBatiment);
	public List<Organe> rechercheOrganeBatiment(int numeroBatiment);
	
	public void ajouttypeextincteur(String nom);
	public List<TypeExtincteur> touslesTypeExtincteur();
	public TypeExtincteur rechercheTypeExtincteur(String Nom);
	public TypeExtincteur rechercheTypeExtincteurNom(String nom);
	
	public void ajoutmarqueextincteur(String nom);
	public List<MarqueExtincteur> touteslesMarqueExtincteur();
	public MarqueExtincteur rechercheMarqueExtincteur(String Nom);
	public MarqueExtincteur rechercheMarqueExtincteurNom(String nom);

	public String rechercheObservationVerification(int numeroOrgane);
	public String rechercheConclusionVerificationExtincteur(int numeroBatiment);
	public String rechercheConclusionVerificationPharmacie(int numeroBatiment);
	
	public String rechercheObservationMaintenanceprev(int numeroOrgane);
	public String rechercheConclusionMaintenanceprev(int numeroBatiment);
	
	public List<Integer> verificationCompte(String login, String pwd) throws CompteInconnuException;
	public void creercompteAdmin( String login, int admin,int statut);
	public String password();
	
	public Piece AjoutPiece(String nom,int numero) throws OrganeInconnuException;
	public void AjoutPieceBD(Piece P);
	public List<Extincteur> rechercheExtincteurParNum(int num);
	public void modifPassWord(int numero,String password);
	
	// eclairage
	public MarqueEclairage rechercheMarqueEclairageNom(String nom);
	public TypeEclairage rechercheTypeEclairageNom(String nom);
	public Typetelecommande rechercheTypeTelecommandeEclairageNom(String nom);
	public List<TypeEclairage> touslesTypeEclairage();
	public List<MarqueEclairage> touteslesMarqueEclairage();
	public List<Typetelecommande> touslesTypeTelecommande();
	public void ajouttypeeclairage(String nom);
	public void ajoutmarqueeclairage(String nom);
	public void ajouttypetelecommandeeclairage(String nom);
	public List<Eclairage> rechercheEclairageBatiment(int numeroBatiment);
	public Eclairage rechercheEclairage(int numeroEclairage);
	public Eclairage remplacementeclairage(Eclairage E, int Annee, String Emp, String Obs, String nommarque, String nomtype,boolean marche,String typetelecommande,int presencetelecom,int fonctionne);
	public String rechercheConclusionMaintenancecorrEclairage(int numeroBatiment);
	public Eclairage ajoutEclairage(int numbatiment, int Annee, String Emp, String Obs, String nomtype,String nommarque,int fonctelecommande,int telecommande,String nomtelecommande) throws BatimentInconnuException;
	public String rechercheConclusionVerificationEclairage(int numeroBatiment);
	
	// Ria
	public TypeRia rechercheTypeRiaNom(String nom);
	public List<TypeRia> touslesTypeRia();
	public List<RIA> rechercheRiaBatiment(int numeroBatiment);
	public void ajouttyperia(String nom);
	public RIA ajoutRIA(int numbatiment,String Emp, String Obs, String nomtype,String pstatique,String pdynamique,String portee) throws BatimentInconnuException;
	public String rechercheConclusionVerificationRia(int numeroBatiment);
	public String rechercheConclusionMaintenancecorrRia(int numeroBatiment);
	public RIA rechercheRIA(int numeroRIA);
	public RIA remplacementria(RIA E, String Emp, String Obs, String pstatique, String nomtype,String pdynamique,String portee,boolean marche);
    // signaletique
	public Signaletique ajoutSignaletique(int numbatiment, String Emp, String Obs) throws BatimentInconnuException;

	// DesenfumageNaturel
	public DesenfumageNaturel ajoutDesenfumage(int numbatiment,String Emp, String Obs, String ouvrant, int quantite,int commandes,int ouvrants,String cartouche,String commande ) throws BatimentInconnuException;
	public String rechercheConclusionVerificationDesenfumageNaturel(int numeroBatiment);
	public String rechercheConclusionMaintenancecorrDesenfumageNaturel(int numeroBatiment);
	public DesenfumageNaturel rechercheDesenfumageNaturel(int numeroDesenfumageNaturel);
	public List<DesenfumageNaturel> rechercheDesenfumageNaturelBatiment(int numeroBatiment);
	public DesenfumageNaturel remplacementdesenfumagenaturel(DesenfumageNaturel D, String Emp, String Obs,String ouvrant, int quantite,int commandes,int ouvrants,String cartouche,String commande,boolean marche);
	public String rechercheConclusionMaintenanceprevdesenfumagenaturel(int numeroBatiment);
	public Organe rechercheOrganeNum(int numeroOrgane);	

}
