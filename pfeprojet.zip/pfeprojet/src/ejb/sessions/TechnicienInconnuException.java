package ejb.sessions;

public class TechnicienInconnuException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
