package ejb.sessions;

import javax.ejb.Remote;

@Remote public interface ServicepfeprojetRemote extends Servicepfeprojet {

}
