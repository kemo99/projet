package ejb.sessions;

public class EntrepriseInconnueException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
