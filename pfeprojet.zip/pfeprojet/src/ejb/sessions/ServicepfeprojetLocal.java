package ejb.sessions;

import javax.ejb.Local;

@Local public interface ServicepfeprojetLocal extends Servicepfeprojet {

}
