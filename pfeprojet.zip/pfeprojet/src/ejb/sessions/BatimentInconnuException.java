package ejb.sessions;

public class BatimentInconnuException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
