package ejb.entites;

import javax.persistence.*;

@Table(name="typealarmeincendie")
@Entity
public class TypeAlarmeIncendie implements java.io.Serializable{

	private static final long serialVersionUID = 1L;
	private int numero;
	private String nom;
	public TypeAlarmeIncendie () { };
	@Column(unique=true, nullable=false) 
	public String getNom () {
		return nom;
	}
	public void setNom (String newnom) {
		this.nom = newnom;
	}
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="typealarmeincendie_sequence")
	@SequenceGenerator(
			name="typealarmeincendie_sequence",
			sequenceName="typealarmeincendie_sequence",
			allocationSize=100
			)
	public int getNumero() {
		return numero;
	}
	public void setNumero(int numero) {
		this.numero = numero;
	}
}
